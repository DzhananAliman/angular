import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './home-page/home-page.component';
import { ZodiacComponent } from './zodiac/zodiac.component';
import { NumerologyComponent } from './numerology/numerology.component';
import { HealthComponent } from './health/health.component';
import { LoginComponent } from './login/login.component';

import { RegisterComponent } from './register/register.component';
import { PostsListComponent } from './posts-list/posts-list.component';
const routes: Routes = [
  { path: 'home-page', component: HomepageComponent },
  { path: 'zodiac', component: ZodiacComponent },
  { path: 'numerology', component: NumerologyComponent },
  { path: 'health', component: HealthComponent },
  { path: 'login', component: LoginComponent },
  {path: 'register', component: RegisterComponent},
  {path: 'posts-list', component: PostsListComponent },

  { path: '', redirectTo: '/home', pathMatch: 'full' } // Път по подразбиране
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

