import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { HttpClient } from '@angular/common/http';





@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NavigationBarComponent,
   ],

  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'HOME';

 constructor(private http: HttpClient) {

 }
 ngOnInit() {
  this.http.get('https://home-20893-default-rtdb.firebaseio.com/comments/.json').subscribe((x) => {
    console.log(x);
  });
 }
  
  onSubmit() {
    
  }
  addComment(){

  }
  editComment() {

  }
  
deleteComment() {

}
  saveComments() {

  }
  onLogout() {

  }

  isShown = true;
 

  togleModal() {
    
    this.isShown = !this.isShown;
  }
}

