import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HerbsComponent } from './app/herbs/herbs.component';
import { FlowearsComponent } from './app/flowears/flowears.component';
import { HomepageComponent } from './app/home-page/home-page.component';
import { HealthComponent } from './app/health/health.component';
import { LoginComponent } from './app/login/login.component';
import { RegisterComponent } from './app/register/register.component';
import { UserComponent } from './app/user/user.component';
import { PostsListComponent } from './app/posts-list/posts-list.component';
const routes: Routes = [
  { path: 'home-page', component: HomepageComponent },
  { path: 'herbs', component: HerbsComponent },
  { path: 'flowears', component: FlowearsComponent },
  { path: 'health', component: HealthComponent },
  { path: 'login', component: LoginComponent },
  {path: 'register', component: RegisterComponent},
  {path: 'user', component: UserComponent},
  {path: 'posts-list', component: PostsListComponent },

  { path: '', redirectTo: '/home', pathMatch: 'full' } // Път по подразбиране
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }





