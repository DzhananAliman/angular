import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { UserService } from './user/user.service';
import { CommonModule } from '@angular/common';
import { PostsListComponent } from './posts-list/posts-list.component';
import { FormsModule } from '@angular/forms';






@Component({
  selector: 'app-root',
  imports: [CommonModule,RouterOutlet,NavigationBarComponent,PostsListComponent,FormsModule
   ],

  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'HOME';

 constructor(private userServie: UserService) {
 }
 isTokenAvailable(): boolean {
  return window.localStorage.getItem('token') !== null;
}

  ngOnInit() {
    const token = this.userServie.getToken();
    if(token) {
      console.log('Token is available:', token);
    }
    }

    ngModel() {

    }

  onSubmit() {
    
  }
  addComment(){

  }
  editComment() {

  }
  
deleteComment() {

}
  saveComments() {

  }
  onLogout() {

  }

  isShown = true;
 

  togleModal() {
    
    this.isShown = !this.isShown;
  }
}

