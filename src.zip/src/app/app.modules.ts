import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HerbsComponent } from './herbs/herbs.component';
import { FlowearsComponent } from './flowears/flowears.component';
import { HealthComponent } from './health/health.component';
import { HomepageComponent } from './home-page/home-page.component';
import { AppRoutingModule } from './app.routing.module';
import { UserModule } from './user/user.module';
import { PostsListComponent } from './posts-list/posts-list.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent, AppRoutingModule,
   ],
  imports: [
    BrowserModule,
    NavigationBarComponent,
    RegisterComponent,
    HerbsComponent,
    FlowearsComponent,
    HealthComponent,
    HomepageComponent, 
    UserModule,
    PostsListComponent,
    CommonModule,
    LoginComponent,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
