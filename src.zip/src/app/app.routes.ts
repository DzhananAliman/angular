import { Routes } from '@angular/router';
import { HerbsComponent } from './herbs/herbs.component';
import { FlowearsComponent } from './flowears/flowears.component';
import { HealthComponent } from './health/health.component';
import { LoginComponent } from './login/login.component';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { HomepageComponent } from './home-page/home-page.component';
import { PostsListComponent } from './posts-list/posts-list.component';

export const routes: Routes = [
  { path: 'herbs', component: HerbsComponent },
  { path: 'flowears', component: FlowearsComponent },
  { path: 'health', component: HealthComponent },
  { path: 'login', component: LoginComponent },
  { path: 'navigation-bar', component: NavigationBarComponent },
  {path: 'home-page', component: HomepageComponent},
  {path: 'posts-list', component: PostsListComponent},
  { path: '', redirectTo: '/zodiac', pathMatch: 'full' }  
];




