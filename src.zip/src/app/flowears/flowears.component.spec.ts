import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowearsComponent, } from './flowears.component';

describe('NumerologyComponent', () => {
  let component: FlowearsComponent;
  let fixture: ComponentFixture<FlowearsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FlowearsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FlowearsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
