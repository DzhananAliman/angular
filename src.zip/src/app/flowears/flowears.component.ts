import { Component } from '@angular/core';

@Component({
  selector: 'app-flowears',
  imports: [],
  templateUrl: './flowears.component.html',
  styleUrl: './flowears.component.css'
})
export class FlowearsComponent {
  title = 'Flowears';

    isShown = true;
   
  
      flowImg = "https://th.bing.com/th?id=OIP.keL-soi4g4OVjWtdYznDtAHaFW&w=200&h=144&rs=1&qlt=80&o=6&dpr=1.5&pid=3.1"
      flow1Img = "https://th.bing.com/th/id/OIP.LTWyCbmQuxGYucoYgycqBgHaE8?w=248&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7" 
      flow2Img =  "https://th.bing.com/th/id/OIP.FVMYVt5-WQCXxUgaP6AeRgHaFX?w=246&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7"
      flow3Img =  "https://th.bing.com/th/id/OIP.nb6o0C63-6uuOoCoE-Q_nQHaG_?w=213&h=201&c=7&r=0&o=5&dpr=1.5&pid=1.7"
}