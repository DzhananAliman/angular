import { Component } from '@angular/core';

@Component({
  selector: 'app-herbs',
  imports: [],
  templateUrl: './herbs.component.html',
  styleUrl: './herbs.component.css'
})
export class HerbsComponent {
  title = 'Herbs';

  isShown = true;
 
herbs1Img = "https://static.framar.bg/filestore/bilki-i-lechebni-rasteniq-framar.jpg"
herbs2Img = "https://cdn.shopify.com/s/files/1/0779/3383/8663/files/jylt-kantarion-bilka.._480x480.webp?v=1720100555"
herbs3Img = "https://th.bing.com/th/id/OIP.ozyYc0xYfdV8WSBLjwTmEgHaEW?w=307&h=181&c=7&r=0&o=5&dpr=1.5&pid=1.7"
herbs4Img = "https://th.bing.com/th/id/OIP.v3WZmA81z-C9OS4C-BP41wHaGh?w=217&h=191&c=7&r=0&o=5&dpr=1.5&pid=1.7"

   
}
