import { Component } from '@angular/core';

@Component({
  selector: 'app-home-item',
  imports: [],
  templateUrl: './home-item.component.html',
  styleUrl: './home-item.component.css'
})
export class HomeItemComponent {

}
