import { Component } from "@angular/core";




@Component({
    selector: 'app-home-page',
    templateUrl: './home-page.component.html',
    styleUrl: `./home-page.component.css`,
    

})
export class HomepageComponent{
    title = 'HOME';

    isShown = true;
   
  
    
      herbsImg = "https://th.bing.com/th?id=OIF.AbD%2bjfA3HA7cTs9mECcBXg&w=220&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7"
      flowearsImg = "https://th.bing.com/th/id/OIP.EaJeko-czhELm5fmIl5NtAHaLG?w=202&h=303&c=7&r=0&o=5&dpr=1.5&pid=1.7"
      healthImg = "https://th.bing.com/th/id/OIP.Gsb6D_wDOiYfw5YK9lV2PgHaE8?w=261&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7"
    
    
}