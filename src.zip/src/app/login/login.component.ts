import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostsListComponent } from '../posts-list/posts-list.component';
import { RegisterComponent } from '../register/register.component';


@Component({
  selector: 'app-login',
 imports: [CommonModule,PostsListComponent,RegisterComponent],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']

})
export class LoginComponent { 
    showRegister = false;

    isTokenAvailable(): boolean {
      return window.localStorage.getItem('token') !== null;
    }

    toggleForm() {
      this.showRegister = !this.showRegister;
    }

 // errorMessage: string = '';
 
  isShown = true;
 


  onSubmit(event: Event) {
    event.preventDefault();  
    
    const emailInput = (event.target as HTMLFormElement).elements.namedItem('email') as HTMLInputElement;
    const passwordInput = (event.target as HTMLFormElement).elements.namedItem('password') as HTMLInputElement;

    const email = emailInput.value;
    const password = passwordInput.value;

    if (!email || !password) {
     alert('Please fill in all fields.');
    } else {
      const token = 'user-token';
      localStorage.setItem('token',token);
      
   
      console.log('Logged in with Email:', email);
      console.log('Password:', password);
     // this.errorMessage = '';  
    }

}   
}
