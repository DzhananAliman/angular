import { Component } from '@angular/core';

@Component({
  selector: 'app-numerology',
  imports: [],
  templateUrl: './numerology.component.html',
  styleUrl: './numerology.component.css'
})
export class NumerologyComponent {
  title = 'Numerology';

    isShown = true;
   
  
      numImg = "https://th.bing.com/th/id/OIP.RARYcwIroFxEtg_7iLNM7gHaEK?w=294&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7"
      num1Img = "https://th.bing.com/th/id/OIP.eW2BJprWyac5KfkWyGaXkAHaJx?w=173&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7" 
      num2Img =  "https://th.bing.com/th/id/OIP.IX-R7oHn0HeKI_zIAbS7JQHaKY?w=153&h=214&c=7&r=0&o=5&dpr=1.5&pid=1.7"
      num3Img =  "https://th.bing.com/th/id/OIP.sBEKAKY-K9FD4nerz3StDgHaHa?w=181&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7"
}