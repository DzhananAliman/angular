import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-posts-list',
  imports: [CommonModule,FormsModule],
  templateUrl: './posts-list.component.html',
  styleUrl: './posts-list.component.css'
})
export class PostsListComponent {
 title = 'Posts'

 

 isShown = true;

 ngModel() {

 }
  
 posts: string[] = [];
 newPost: string = '';

 addPost() {
  if(this.newPost) {
    this.posts.push(this.newPost);
    this.newPost = '';

  }
 }

 deletePost(index: number) {
  this.posts.splice(index, 1);
 }
 editPost(index: number) {
  const updatedPost = prompt('Edit your post:', this.posts[index]);
  if(updatedPost !== null) {
    this.posts[index] = updatedPost;
  }
 }
     
}
