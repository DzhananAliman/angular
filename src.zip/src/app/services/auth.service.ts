
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() {}

 
  isLoggedIn(): boolean {
    return sessionStorage.getItem('user') !== null;
  }

  
  login(username: string, password: string): boolean {
    
    if (username && password) {
      sessionStorage.setItem('user', JSON.stringify({ username }));
      return true;
    }
    return false;
  }


  logout(): void {
    sessionStorage.removeItem('user');
  }


  getCurrentUser() {
    return JSON.parse(sessionStorage.getItem('user') || '{}');
  }
}
