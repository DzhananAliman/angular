export const environment = {
production: false,
firebase: {
    apiKey: "AIzaSyBaKyvMQ5XkirfOKxnsiaH1oQ0HDL2po7I",
    authDomain: "home-20893.firebaseapp.com",
    databaseURL: "https://home-20893-default-rtdb.firebaseio.com",
    projectId: "home-20893",
    storageBucket: "home-20893.firebasestorage.app",
    messagingSenderId: "922927037961",
    appId: "1:922927037961:web:3672878eee9bde940602d8",
    measurementId: "G-WWTNLC4TKM"
}
};
